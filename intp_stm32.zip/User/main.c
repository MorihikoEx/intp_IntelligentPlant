#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "SHT30.h"
#include "ADC.h"
#include "Key.h"
#include "LED_Light.h"
#include "Servo.h"
#include "Motor.h"
#include "ESP8266.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// ================= 系统全局状态 =================
uint8_t menuLevel = 20;
uint8_t autoEnable = 1;
uint8_t wifiEnabled = 0;
uint8_t wifiStatus = 0;
uint8_t tcpStatus = 0;

// ================= 传感器数据 =================
float temperature = 0, humidity = 0;
int tempInt = 0, humiInt = 0;
uint16_t lightVal = 0, soilVal = 0;
uint8_t lightPer = 0, soilPer = 0;
char displayBuf[32];

#define ADC_FILTER_COUNT 10
uint16_t lightBuf[ADC_FILTER_COUNT] = {0};
uint16_t soilBuf[ADC_FILTER_COUNT] = {0};

// ================= 执行机构状态与阈值 =================
uint8_t ledState = 0;
uint8_t servoAngle = 0;
uint8_t pumpState = 0;
uint8_t fanState = 0;

// 统一阈值配置（RAM，不掉电保存）
int tempThreshLow = 18;
int tempThreshHigh = 30;
uint16_t lightThreshLow = 200;
uint16_t lightThreshHigh = 1500;
uint16_t soilThreshLow = 1200;
uint16_t soilThreshHigh = 2600;
uint16_t configVersion = 1;

// ================= 菜单光标与格式 =================
uint8_t cursorMain = 0;
uint8_t cursorManual = 0;
uint8_t dataFormat = 0;

// ================= 自动连接控制 =================
uint8_t wifiAutoStarted = 0;
uint8_t tcpAutoStarted = 0;
uint16_t wifiRetryTick = 0;
uint16_t tcpRetryTick = 0;

// ================= 函数声明 =================
void SystemAutoLogic(void);
void ResetActuators(void);
void DataAcquisition(void);
uint8_t WaitResponse(char* target, uint16_t timeout_ms);
uint8_t ESP8266_ConnectWiFi(void);
uint8_t ESP8266_ConnectTCP(void);
void WiFi_AutoTask(void);
void DisplayAutoMonitor(uint8_t key);
void DisplayMainMenu(uint8_t key);
void DisplayManualPanel(uint8_t key);
void DisplayWiFiControl(uint8_t key);

uint8_t SendTcpJson(const char *json);
void SendTelemetry(void);
void SendThreshold(void);
void SendThresholdAck(uint8_t success);
void ProcessEsp8266Message(void);
void HandleTcpPayload(char *payload);
int ExtractJsonInt(const char *json, const char *key, int *value);

// ================= 复位执行机构 =================
void ResetActuators(void) {
    servoAngle = 0;
    Servo_SetAngle(0);
    ledState = 0;
    LED_Light_OFF();

    pumpState = 0;
    fanState = 0;
    Pump_Off();
    Fan_Off();
}

// ================= 数据采集与滤波 =================
void DataAcquisition(void) {
    SHT30_Read_Data(&temperature, &humidity);
    uint16_t rawLight = ADC_GetValue(ADC_Channel_0);
    uint16_t rawSoil = ADC_GetValue(ADC_Channel_1);

    static uint8_t lightIdx = 0;
    static uint8_t soilIdx = 0;
    uint32_t lightSum = 0, soilSum = 0;
    uint8_t i;

    lightBuf[lightIdx] = rawLight;
    lightIdx++;
    if(lightIdx >= ADC_FILTER_COUNT) lightIdx = 0;

    soilBuf[soilIdx] = rawSoil;
    soilIdx++;
    if(soilIdx >= ADC_FILTER_COUNT) soilIdx = 0;

    for(i = 0; i < ADC_FILTER_COUNT; i++) {
        lightSum += lightBuf[i];
        soilSum += soilBuf[i];
    }

    lightVal = (uint16_t)(lightSum / ADC_FILTER_COUNT);
    soilVal = (uint16_t)(soilSum / ADC_FILTER_COUNT);

    tempInt = (int)temperature;
    humiInt = (int)humidity;
    lightPer = 100 - (lightVal * 100 / 4095);
    soilPer = 100 - (soilVal * 100 / 4095);
}

// ================= 自动控制逻辑 =================
void SystemAutoLogic(void) {
    if(autoEnable != 1) return;

    if(lightVal < lightThreshLow) {
        if(servoAngle != 0) {
            servoAngle = 0;
            Servo_SetAngle(0);
        }
        if(ledState != 0) {
            ledState = 0;
            LED_Light_OFF();
        }
    } else if(lightVal > lightThreshHigh) {
        if(servoAngle != 90) {
            servoAngle = 90;
            Servo_SetAngle(90);
        }
        if(ledState != 1) {
            ledState = 1;
            LED_Light_ON();
        }
    }

    if(soilVal < soilThreshLow) {
        if(pumpState == 0) {
            pumpState = 1;
            Pump_On();
        }
    } else if(soilVal > soilThreshHigh) {
        if(pumpState == 1) {
            pumpState = 0;
            Pump_Off();
        }
    }

    if(tempInt > tempThreshHigh) {
        if(fanState == 0) {
            fanState = 1;
            Fan_On();
        }
    } else if(tempInt < tempThreshLow) {
        if(fanState == 1) {
            fanState = 0;
            Fan_Off();
        }
    }
}

// ================= 串口等待工具 =================
uint8_t WaitResponse(char* target, uint16_t timeout_ms) {
    uint16_t tick = 0;
    while(tick < timeout_ms) {
        if(ESP8266_RxFlag == 1) {
            ESP8266_RxFlag = 0;
            if(ESP8266_RxLen > 0 && ESP8266_RxLen < 512) {
                ESP8266_RxBuf[ESP8266_RxLen] = '\0';
                if(strstr((char*)ESP8266_RxBuf, target) != NULL) {
                    ESP8266_RxLen = 0;
                    return 1;
                }
            }
            ESP8266_RxLen = 0;
        }
        Delay_ms(10);
        tick += 10;
    }
    return 0;
}

// ================= WiFi连接 =================
uint8_t ESP8266_ConnectWiFi(void) {
    wifiStatus = 1;
    wifiEnabled = 0;

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT\r\n");
    if(!WaitResponse("OK", 1000)) {
        wifiStatus = 3;
        return 0;
    }

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT+CWMODE=1\r\n");
    WaitResponse("OK", 1000);

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT+CIPMUX=0\r\n");
    WaitResponse("OK", 1000);

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT+CIPMODE=0\r\n");
    WaitResponse("OK", 1000);

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT+CWJAP=\"xwx\",\"23322885\"\r\n");
    if(WaitResponse("WIFI CONNECTED", 8000) || WaitResponse("OK", 8000)) {
        wifiEnabled = 1;
        wifiStatus = 2;
        return 1;
    }

    wifiStatus = 3;
    return 0;
}

// ================= TCP连接 =================
uint8_t ESP8266_ConnectTCP(void) {
    if(wifiEnabled == 0) {
        tcpStatus = 3;
        return 0;
    }

    tcpStatus = 1;
    tcpLinked = 0;

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT+CIPCLOSE\r\n");
    WaitResponse("OK", 1000);

    ESP8266_ClearBuffer();
    ESP8266_SendString("AT+CIPSTART=\"TCP\",\"10.160.99.222\",8080\r\n");
    if(WaitResponse("CONNECT", 5000) || WaitResponse("OK", 5000) || WaitResponse("ALREADY CONNECTED", 3000)) {
        tcpLinked = 1;
        tcpStatus = 2;
        return 1;
    }

    tcpStatus = 3;
    tcpLinked = 0;
    return 0;
}

// ================= 自动连接任务 =================
void WiFi_AutoTask(void) {
    if(wifiEnabled == 0) {
        if(wifiAutoStarted == 0) {
            wifiAutoStarted = 1;
            ESP8266_ConnectWiFi();
        } else if(wifiStatus == 3) {
            wifiRetryTick++;
            if(wifiRetryTick >= 500) {
                wifiRetryTick = 0;
                ESP8266_ConnectWiFi();
            }
        }
        return;
    }

    if(tcpLinked == 0) {
        if(tcpAutoStarted == 0) {
            tcpAutoStarted = 1;
            ESP8266_ConnectTCP();
        } else if(tcpStatus == 3) {
            tcpRetryTick++;
            if(tcpRetryTick >= 500) {
                tcpRetryTick = 0;
                ESP8266_ConnectTCP();
            }
        }
    }
}

// ================= TCP发送一个JSON行 =================
uint8_t SendTcpJson(const char *json) {
    char cmdBuf[32];

    if(tcpLinked != 1) {
        return 0;
    }

    ESP8266_ClearBuffer();
    sprintf(cmdBuf, "AT+CIPSEND=%d\r\n", (int)strlen(json));
    ESP8266_SendString(cmdBuf);

    if(WaitResponse(">", 1000)) {
        ESP8266_SendString((char *)json);
        return 1;
    }

    tcpLinked = 0;
    tcpStatus = 3;
    tcpAutoStarted = 0;
    return 0;
}

// ================= 上报传感器数据 =================
void SendTelemetry(void) {
    char jsonBuf[160];

    sprintf(
        jsonBuf,
        "{\"type\":\"telemetry\",\"temperature\":%d,\"humidity\":%d,\"light\":%d,\"soil\":%d}\n",
        tempInt,
        humiInt,
        lightVal,
        soilVal
    );

    SendTcpJson(jsonBuf);
}

// ================= 发送当前阈值 =================
void SendThreshold(void) {
    char jsonBuf[220];

    sprintf(
        jsonBuf,
        "{\"type\":\"threshold\",\"configVersion\":%d,\"tempLow\":%d,\"tempHigh\":%d,\"lightLow\":%d,\"lightHigh\":%d,\"soilLow\":%d,\"soilHigh\":%d}\n",
        configVersion,
        tempThreshLow,
        tempThreshHigh,
        lightThreshLow,
        lightThreshHigh,
        soilThreshLow,
        soilThreshHigh
    );

    SendTcpJson(jsonBuf);
}

// ================= 发送阈值设置应答 =================
void SendThresholdAck(uint8_t success) {
    char jsonBuf[240];

    sprintf(
        jsonBuf,
        "{\"type\":\"set_threshold_ack\",\"success\":%s,\"configVersion\":%d,\"tempLow\":%d,\"tempHigh\":%d,\"lightLow\":%d,\"lightHigh\":%d,\"soilLow\":%d,\"soilHigh\":%d}\n",
        success ? "true" : "false",
        configVersion,
        tempThreshLow,
        tempThreshHigh,
        lightThreshLow,
        lightThreshHigh,
        soilThreshLow,
        soilThreshHigh
    );

    SendTcpJson(jsonBuf);
}

// ================= 从JSON中提取整数值（固定格式简单解析） =================
int ExtractJsonInt(const char *json, const char *key, int *value) {
    char pattern[40];
    char *pos;
    char *start;

    sprintf(pattern, "\"%s\":", key);
    pos = strstr((char *)json, pattern);
    if(pos == NULL) {
        return 0;
    }

    start = pos + strlen(pattern);
    *value = atoi(start);
    return 1;
}

// ================= 处理TCP业务负载 =================
void HandleTcpPayload(char *payload) {
    int tempLow, tempHigh, lightLow, lightHigh, soilLow, soilHigh, version;
    uint8_t ok;

    if(strstr(payload, "\"type\":\"get_threshold\"") != NULL) {
        SendThreshold();
        return;
    }

    if(strstr(payload, "\"type\":\"set_threshold\"") != NULL) {
        ok = 1;

        if(!ExtractJsonInt(payload, "configVersion", &version)) ok = 0;
        if(!ExtractJsonInt(payload, "tempLow", &tempLow)) ok = 0;
        if(!ExtractJsonInt(payload, "tempHigh", &tempHigh)) ok = 0;
        if(!ExtractJsonInt(payload, "lightLow", &lightLow)) ok = 0;
        if(!ExtractJsonInt(payload, "lightHigh", &lightHigh)) ok = 0;
        if(!ExtractJsonInt(payload, "soilLow", &soilLow)) ok = 0;
        if(!ExtractJsonInt(payload, "soilHigh", &soilHigh)) ok = 0;

        if(ok) {
            if(tempLow > tempHigh) ok = 0;
            if(lightLow > lightHigh) ok = 0;
            if(soilLow > soilHigh) ok = 0;

            if(tempLow < -40 || tempLow > 100) ok = 0;
            if(tempHigh < -40 || tempHigh > 100) ok = 0;

            if(lightLow < 0 || lightLow > 4095) ok = 0;
            if(lightHigh < 0 || lightHigh > 4095) ok = 0;

            if(soilLow < 0 || soilLow > 4095) ok = 0;
            if(soilHigh < 0 || soilHigh > 4095) ok = 0;

            if(version < 0 || version > 65535) ok = 0;
        }

        if(ok) {
            tempThreshLow = tempLow;
            tempThreshHigh = tempHigh;
            lightThreshLow = (uint16_t)lightLow;
            lightThreshHigh = (uint16_t)lightHigh;
            soilThreshLow = (uint16_t)soilLow;
            soilThreshHigh = (uint16_t)soilHigh;
            configVersion = (uint16_t)version;
            SendThresholdAck(1);
        } else {
            SendThresholdAck(0);
        }

        return;
    }
}

// ================= 处理ESP8266串口消息 =================
void ProcessEsp8266Message(void) {
    char *ipdStart;
    char *payloadStart;

    if(ESP8266_RxLen < 512) {
        ESP8266_RxBuf[ESP8266_RxLen] = '\0';
    } else {
        ESP8266_RxBuf[511] = '\0';
    }

    if(strstr((char*)ESP8266_RxBuf, "CLOSED") != NULL ||
       strstr((char*)ESP8266_RxBuf, "ERROR") != NULL ||
       strstr((char*)ESP8266_RxBuf, "FAIL") != NULL) {
        tcpLinked = 0;
        tcpStatus = 3;
        tcpAutoStarted = 0;
    }

    ipdStart = strstr((char*)ESP8266_RxBuf, "+IPD,");
    if(ipdStart != NULL) {
        payloadStart = strchr(ipdStart, ':');
        if(payloadStart != NULL) {
            payloadStart++;
            HandleTcpPayload(payloadStart);
        }
    }

    ESP8266_RxLen = 0;
    ESP8266_RxFlag = 0;
}

// ================= 主函数 =================
int main(void) {
    OLED_Init();
    MyADC_Init();
    SHT30_Init();
    Key_Init();
    LED_Light_Init();
    Servo_Init();
    Motor_Init();
    ESP8266_Init();
    ResetActuators();

    OLED_Clear();
    OLED_ShowString(1, 1, "System Start");
    OLED_ShowString(2, 1, "WiFi Auto...");
    Delay_ms(500);

    while(1) {
        Key_Loop();
        {
            uint8_t key = Key_GetNum();
            DataAcquisition();
            SystemAutoLogic();
            WiFi_AutoTask();

            switch(menuLevel) {
                case 20: DisplayAutoMonitor(key); break;
                case 0:  DisplayMainMenu(key); break;
                case 30: DisplayManualPanel(key); break;
                case 3:  DisplayWiFiControl(key); break;
            }
        }

        if(ESP8266_RxFlag == 1) {
            ProcessEsp8266Message();
        }

        if(tcpLinked == 1) {
            wifiSendTick++;
            if(wifiSendTick >= 100) {
                wifiSendTick = 0;
                SendTelemetry();
            }
        }

        Delay_ms(10);
    }
}

// ================= 界面1：自动监测 =================
void DisplayAutoMonitor(uint8_t key) {
    if(key == KEY_CONFIRM) dataFormat = !dataFormat;
    if(key == KEY_BACK) {
        OLED_Clear();
        menuLevel = 0;
        return;
    }

    OLED_ShowString(1, 1, "[Auto] ");
    sprintf(displayBuf, "T:%3dC H:%3d%% ", tempInt, humiInt);
    OLED_ShowString(2, 1, displayBuf);

    if(dataFormat == 0) sprintf(displayBuf, "L:%3d%% ", lightPer);
    else sprintf(displayBuf, "L:%4d ", lightVal);
    OLED_ShowString(3, 1, displayBuf);

    if(dataFormat == 0) sprintf(displayBuf, "S:%3d%% ", soilPer);
    else sprintf(displayBuf, "S:%4d ", soilVal);
    OLED_ShowString(4, 1, displayBuf);
}

// ================= 界面2：主菜单 =================
void DisplayMainMenu(uint8_t key) {
    if(key == KEY_SELECT) cursorMain = (cursorMain + 1) % 3;

    if(key == KEY_CONFIRM) {
        OLED_Clear();
        if(cursorMain == 0) menuLevel = 30;
        else if(cursorMain == 1) {
            menuLevel = 20;
            autoEnable = 1;
        } else if(cursorMain == 2) {
            menuLevel = 3;
        }
        return;
    }

    if(key == KEY_BACK) {
        OLED_Clear();
        menuLevel = 20;
        autoEnable = 1;
        return;
    }

    OLED_ShowChar(1, 1, cursorMain == 0 ? '>' : ' ');
    OLED_ShowString(1, 2, "1.Manual ");
    OLED_ShowChar(2, 1, cursorMain == 1 ? '>' : ' ');
    OLED_ShowString(2, 2, "2.Environment ");
    OLED_ShowChar(3, 1, cursorMain == 2 ? '>' : ' ');
    OLED_ShowString(3, 2, "3.WiFi Ctrl ");
    OLED_ShowString(4, 1, " ");
}

// ================= 界面3：手动控制 =================
void DisplayManualPanel(uint8_t key) {
    autoEnable = 0;

    if(key == KEY_SELECT) cursorManual = (cursorManual + 1) % 4;

    if(key == KEY_CONFIRM) {
        if(cursorManual == 0) {
            if(servoAngle == 0) servoAngle = 90;
            else servoAngle = 0;
            Servo_SetAngle(servoAngle);
        } else if(cursorManual == 1) {
            ledState = !ledState;
            if(ledState == 1) LED_Light_ON();
            else LED_Light_OFF();
        } else if(cursorManual == 2) {
            pumpState = !pumpState;
            if(pumpState == 1) Pump_On();
            else Pump_Off();
        } else if(cursorManual == 3) {
            fanState = !fanState;
            if(fanState == 1) Fan_On();
            else Fan_Off();
        }
    }

    if(key == KEY_BACK) {
        OLED_Clear();
        ResetActuators();
        autoEnable = 1;
        menuLevel = 0;
        return;
    }

    OLED_ShowChar(1, 1, cursorManual == 0 ? '>' : ' ');
    if(servoAngle == 0) OLED_ShowString(1, 2, "Servo:OFF ");
    else OLED_ShowString(1, 2, "Servo:ON  ");

    OLED_ShowChar(2, 1, cursorManual == 1 ? '>' : ' ');
    if(ledState == 1) OLED_ShowString(2, 2, "LED  :ON  ");
    else OLED_ShowString(2, 2, "LED  :OFF ");

    OLED_ShowChar(3, 1, cursorManual == 2 ? '>' : ' ');
    if(pumpState == 1) OLED_ShowString(3, 2, "Pump :ON  ");
    else OLED_ShowString(3, 2, "Pump :OFF ");

    OLED_ShowChar(4, 1, cursorManual == 3 ? '>' : ' ');
    if(fanState == 1) OLED_ShowString(4, 2, "Fan  :ON  ");
    else OLED_ShowString(4, 2, "Fan  :OFF ");
}

// ================= 界面4：WiFi控制 =================
void DisplayWiFiControl(uint8_t key) {
    if(key == KEY_CONFIRM) {
        OLED_Clear();
        if(wifiEnabled == 0) {
            ESP8266_ConnectWiFi();
            tcpAutoStarted = 0;
        } else if(tcpLinked == 0) {
            ESP8266_ConnectTCP();
        }
        return;
    }

    if(key == KEY_BACK) {
        OLED_Clear();
        menuLevel = 0;
        return;
    }

    OLED_ShowString(1, 1, "[WiFi Connect]");

    if(wifiStatus == 2) OLED_ShowString(2, 1, "WiFi:OK      ");
    else if(wifiStatus == 1) OLED_ShowString(2, 1, "WiFi:Linking ");
    else if(wifiStatus == 3) OLED_ShowString(2, 1, "WiFi:Fail    ");
    else OLED_ShowString(2, 1, "WiFi:Ready   ");

    if(tcpStatus == 2) OLED_ShowString(3, 1, "TCP:OK       ");
    else if(tcpStatus == 1) OLED_ShowString(3, 1, "TCP:Linking  ");
    else if(tcpStatus == 3) OLED_ShowString(3, 1, "TCP:Fail     ");
    else OLED_ShowString(3, 1, "TCP:Ready    ");

    if(tcpLinked == 1) OLED_ShowString(4, 1, "Sending Data ");
    else OLED_ShowString(4, 1, "Auto Connect ");
}
