#include "stm32f10x.h"
#include "RTC.h"

// 获取当前时间
void RTC_GetTime(RTC_TimeTypeDef* time) {
    time->year  = (uint8_t)(RTC->CNTH & 0xFF); // 取高8位年份简化处理
    time->month = BKP_ReadBackupRegister(BKP_DR1);
    time->day   = BKP_ReadBackupRegister(BKP_DR2);
    time->hour  = RTC->CNTH & 0xFF;  // 实际应用中需完整解析32位计数器
    time->min   = RTC->CNTL & 0xFF;
    time->sec   = (RTC->CNTL >> 8) & 0xFF;
}

// 简易RTC初始化 (带默认时间设置)
void RTC_Init(void) {
    // 1. 开启PWR和BKP时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
    
    // 2. 允许访问备份寄存器
    PWR_BackupAccessCmd(ENABLE);
    
    // 3. 检查是否是第一次配置 (通过备份寄存器标志位判断)
    if (BKP_ReadBackupRegister(BKP_DR3) != 0xA5A5) {
        // 第一次运行，配置RTC
        RCC_LSEConfig(RCC_LSE_OFF);         // 关闭外部低速晶振(通常板子没焊)
        RCC_LSICmd(ENABLE);                 // 开启内部低速晶振 (约40kHz)
        while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);
        
        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI); // 选择LSI作为RTC时钟
        RCC_RTCCLKCmd(ENABLE);               // 开启RTC时钟
        
        RTC_WaitForLastTask();
        RTC_WaitForSynchro();
        
        RTC_SetPrescaler(40000 - 1);         // LSI约40kHz，分频后产生1Hz秒脉冲
        RTC_WaitForLastTask();
        
        // 设置默认时间：2024年1月1日 12:00:00
        RTC_SetCounter(0);                   // 清空计数器
        BKP_WriteBackupRegister(BKP_DR1, 1); // 写入月份 1
        BKP_WriteBackupRegister(BKP_DR2, 1); // 写入日期 1
        BKP_WriteBackupRegister(BKP_DR3, 0xA5A5); // 写入初始化标志
        
        RTC_WaitForLastTask();
    } else {
        // 不是第一次运行，等待同步即可
        RTC_WaitForSynchro();
        RTC_WaitForLastTask();
    }
}
