#ifndef __RTC_H
#define __RTC_H

// 时间结构体
typedef struct {
    uint8_t year;   // 例：24 代表 2024年
    uint8_t month;  // 1~12
    uint8_t day;    // 1~31
    uint8_t hour;   // 0~23
    uint8_t min;    // 0~59
    uint8_t sec;    // 0~59
} RTC_TimeTypeDef;

void RTC_Init(void);
void RTC_GetTime(RTC_TimeTypeDef* time);

#endif
