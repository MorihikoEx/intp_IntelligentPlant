#ifndef __KEY_H
#define __KEY_H

// 定义键码宏，方便阅读
#define KEY_NONE   0
#define KEY_SELECT 1  // PB14 循环选择
#define KEY_CONFIRM 2 // PB13 确认
#define KEY_BACK   3  // PB15 返回

void Key_Init(void);
void Key_Loop(void);      // 必须在主循环中高频调用
uint8_t Key_GetNum(void); // 获取当前按下的键码

#endif
