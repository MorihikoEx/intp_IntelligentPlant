#ifndef __ADC_H
#define __ADC_H

void MyADC_Init(void);  
uint16_t ADC_GetValue(uint8_t Channel);

#endif
