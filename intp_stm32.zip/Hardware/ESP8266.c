#include "stm32f10x.h"
#include "ESP8266.h"
#include <string.h>

uint8_t ESP8266_RxBuf[512];
uint16_t ESP8266_RxLen = 0;
uint8_t ESP8266_RxFlag = 0;

uint8_t tcpLinked = 0;
uint16_t wifiSendTick = 0;

void ESP8266_ClearBuffer(void)
{
    uint16_t i;
    for(i = 0; i < 512; i++)
    {
        ESP8266_RxBuf[i] = 0;
    }
    ESP8266_RxLen = 0;
    ESP8266_RxFlag = 0;
}

void ESP8266_SendByte(uint8_t Byte)
{
    USART_SendData(USART1, Byte);
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void ESP8266_SendString(char *String)
{
    while(*String)
    {
        ESP8266_SendByte(*String++);
    }
}

void ESP8266_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* PA9 -> USART1_TX */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* PA10 -> USART1_RX */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);

    ESP8266_ClearBuffer();
}

void USART1_IRQHandler(void)
{
    uint8_t data;

    if(USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
    {
        data = USART_ReceiveData(USART1);

        if(ESP8266_RxLen < sizeof(ESP8266_RxBuf) - 1)
        {
            ESP8266_RxBuf[ESP8266_RxLen++] = data;
        }
        else
        {
            ESP8266_RxLen = 0;
        }

        if(data == '\n')
        {
            ESP8266_RxBuf[ESP8266_RxLen] = '\0';
            ESP8266_RxFlag = 1;

            if(strstr((char *)ESP8266_RxBuf, "CONNECT") != 0)
            {
                tcpLinked = 1;
            }
            if(strstr((char *)ESP8266_RxBuf, "CLOSED") != 0)
            {
                tcpLinked = 0;
            }
        }

        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}
