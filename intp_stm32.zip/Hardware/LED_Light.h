#ifndef __LED_LIGHT_H
#define __LED_LIGHT_H

void LED_Light_Init(void);
void LED_Light_ON(void);
void LED_Light_OFF(void);
void LED_Light_Turn(void);

#endif
