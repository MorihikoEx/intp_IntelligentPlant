#include "stm32f10x.h"
#include "Delay.h"
#include "sht30.h"

// 复用 PB6 和 PB7 引脚宏定义（与OLED保持一致）
#define SHT_SCL(x) GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)(x))
#define SHT_SDA(x) GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)(x))
#define READ_SDA   GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7)

// SHT30 地址 (0x44 左移1位)
#define SHT30_ADDR_WRITE   0x88  
#define SHT30_ADDR_READ    0x89

// 软件I2C底层时序
void I2C_Start(void) {
    SHT_SDA(1); SHT_SCL(1); Delay_us(5);
    SHT_SDA(0); Delay_us(5);
    SHT_SCL(0); Delay_us(5);
}

void I2C_Stop(void) {
    SHT_SDA(0); SHT_SCL(1); Delay_us(5);
    SHT_SDA(1); Delay_us(5);
}

void I2C_SendByte(uint8_t Byte) {
    uint8_t i;
    for (i = 0; i < 8; i++) {
        SHT_SDA(!!(Byte & (0x80 >> i)));
        SHT_SCL(1); Delay_us(5);
        SHT_SCL(0); Delay_us(5);
    }
    SHT_SDA(1); // 释放SDA，准备接收ACK
}

uint8_t I2C_ReadByte(void) {
    uint8_t i, Byte = 0;
    SHT_SDA(1); // 释放SDA
    for (i = 0; i < 8; i++) {
        SHT_SCL(1); Delay_us(5);
        if (READ_SDA) Byte |= (0x80 >> i);
        SHT_SCL(0); Delay_us(5);
    }
    return Byte;
}

// 等待应答 (0:ACK, 1:NACK)
uint8_t I2C_WaitAck(void) {
    uint8_t ack;
    SHT_SCL(1); Delay_us(5);
    ack = READ_SDA;
    SHT_SCL(0); Delay_us(5);
    return ack;
}

// 发送应答/非应答
void I2C_SendAck(uint8_t ack) {
    SHT_SDA(ack);
    SHT_SCL(1); Delay_us(5);
    SHT_SCL(0); Delay_us(5);
    SHT_SDA(1);
}

// SHT30初始化 (确保引脚为开漏输出)
void SHT30_Init(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    SHT_SCL(1);
    SHT_SDA(1);
}

// 读取温湿度
uint8_t SHT30_Read_Data(float *Temp, float *Humi) {
    uint8_t buf[6];
    uint16_t st, srh;
    
    // 1. 发送测量命令
    I2C_Start();
    I2C_SendByte(SHT30_ADDR_WRITE);
    if(I2C_WaitAck()) return 1;
    
    I2C_SendByte(0x24); // 高精度，无时钟拉伸
    if(I2C_WaitAck()) return 1;
    
    I2C_SendByte(0x00);
    if(I2C_WaitAck()) return 1;
    I2C_Stop();
    
    // 2. 等待测量完成
    Delay_ms(20);
    
    // 3. 读取6个字节数据
    I2C_Start();
    I2C_SendByte(SHT30_ADDR_READ);
    if(I2C_WaitAck()) return 1;
    
    for(uint8_t i = 0; i < 6; i++) {
        buf[i] = I2C_ReadByte();
        if(i == 5) {
            I2C_SendAck(1); // 最后一个字节发NACK
        } else {
            I2C_SendAck(0); // 中间字节发ACK
        }
    }
    I2C_Stop();
    
    // 4. 数据转换
    st = (buf[0] << 8) | buf[1];
    srh = (buf[3] << 8) | buf[4];
    
    *Temp = -45.0 + 175.0 * ((float)st / 65535.0);
    *Humi = 100.0 * ((float)srh / 65535.0);
    
    return 0;
}
