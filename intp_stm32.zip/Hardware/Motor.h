#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"

void Motor_Init(void);

void Pump_On(void);
void Pump_Off(void);

void Fan_On(void);
void Fan_Off(void);

void Pump_SetSpeed(uint16_t duty);
void Fan_SetSpeed(uint16_t duty);

#endif
