#ifndef __ESP8266_H
#define __ESP8266_H

#include "stm32f10x.h"

extern uint8_t ESP8266_RxBuf[512];
extern uint16_t ESP8266_RxLen;
extern uint8_t ESP8266_RxFlag;

extern uint8_t tcpLinked;
extern uint16_t wifiSendTick;

void ESP8266_Init(void);
void ESP8266_SendByte(uint8_t Byte);
void ESP8266_SendString(char *String);
void ESP8266_ClearBuffer(void);

#endif
