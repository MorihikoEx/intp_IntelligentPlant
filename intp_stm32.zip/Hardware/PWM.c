#include "stm32f10x.h" // Device header

/**
 * 函 数：PWM初始化
 * 参 数：无
 * 返 回 值：无
 */
void PWM_Init(void)
{
	/*开启时钟*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);  // TIM2 改为 TIM3
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;             // PA1 改为 PA6
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	/*配置时钟源*/
	TIM_InternalClockConfig(TIM3);                        // TIM2 改为 TIM3
	
	/*时基单元初始化*/
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;     // 50Hz频率，适合舵机
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);   // TIM2 改为 TIM3
	
	/*输出比较初始化*/
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);              // OC2Init 改为 OC1Init，TIM2 改为 TIM3
	
	/*TIM使能*/
	TIM_Cmd(TIM3, ENABLE);                                // TIM2 改为 TIM3
}

/**
 * 函 数：PWM设置CCR
 * 参 数：Compare 要写入的CCR的值
 * 返 回 值：无
 */
void PWM_SetCompare1(uint16_t Compare)                   // 函数名改为SetCompare1
{
	TIM_SetCompare1(TIM3, Compare);                       // SetCompare2 改为 SetCompare1，TIM2 改为 TIM3
}
