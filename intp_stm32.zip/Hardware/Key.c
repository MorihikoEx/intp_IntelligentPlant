#include "stm32f10x.h"
#include "Key.h"

uint8_t Key_Num = KEY_NONE; // 存储键码的全局变量

void Key_Init(void) {
    /*开启时钟*/
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    /*GPIO初始化*/
    GPIO_InitTypeDef GPIO_InitStructure;
    // 关键修改：改为下拉输入 (IPD)，因为按键接 3.3V
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 
    // 关键修改：引脚改为 PB13, PB14, PB15
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

/*
 * @brief  非阻塞按键扫描函数（状态机）
 * @note   必须在 main.c 的 while(1) 里不断调用，建议配合 10ms 定时器或直接放循环里
 */
void Key_Loop(void) {
    static uint8_t key_state = 0; // 0:空闲, 1:消抖, 2:等待松手
    static uint16_t key_time = 0;
    
    uint8_t key_press = KEY_NONE;
    
    // 读取物理引脚状态 (接3.3V，按下为1)
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == 1) key_press = KEY_SELECT;
    else if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_13) == 1) key_press = KEY_CONFIRM;
    else if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_15) == 1) key_press = KEY_BACK;

    switch(key_state) {
        case 0: // 空闲状态
            if (key_press != KEY_NONE) {
                key_state = 1;   // 检测到按键，进入消抖状态
                key_time = 0;
            }
            break;
            
        case 1: // 消抖状态
            if (key_press != KEY_NONE) {
                key_time++;      // 记录按下时间
                if (key_time > 2) { // 大约 20ms (如果主循环是10ms调用一次的话)
                    Key_Num = key_press; // 确认有效按键，记录键码
                    key_state = 2;       // 进入等待松手状态
                }
            } else {
                key_state = 0;   // 抖动消失了，认为是干扰，回退
            }
            break;
            
        case 2: // 等待松手状态
            if (key_press == KEY_NONE) {
                Key_Num = KEY_NONE; // 检测到松手，清空键码，防止连续触发
                key_state = 0;      // 回到空闲
            }
            break;
    }
}

// 获取键码
uint8_t Key_GetNum(void) {
    return Key_Num;
}
