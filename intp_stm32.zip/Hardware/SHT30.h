#ifndef __SHT30_H
#define __SHT30_H

void SHT30_Init(void);
uint8_t SHT30_Read_Data(float *Temp, float *Humi);

#endif
