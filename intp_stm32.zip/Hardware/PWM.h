#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);
void PWM_SetCompare1(uint16_t Compare); // 原来是SetCompare2，现改为通道1

#endif
