#include "stm32f10x.h"

// 初始化补光灯 PB12
void LED_Light_Init(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; // 推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    GPIO_SetBits(GPIOB, GPIO_Pin_12); // 默认关闭(高电平关，低电平开，看你的接线，这里假设高电平关)
}

void LED_Light_ON(void) {
		GPIO_SetBits(GPIOB, GPIO_Pin_12);// 低电平点亮
}

void LED_Light_OFF(void) {
		GPIO_ResetBits(GPIOB, GPIO_Pin_12);// 高电平熄灭
}

void LED_Light_Turn(void) {
    if (GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_12) == 0) {
        GPIO_SetBits(GPIOB, GPIO_Pin_12);
    } else {
        GPIO_ResetBits(GPIOB, GPIO_Pin_12);
    }
}
